<?php

function config() {
    include CONFIG_PATH . 'config.php';
}