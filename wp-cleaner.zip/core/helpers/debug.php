<?php

use simplerest\core\libs\VarDump;

function dd($var, $msg = null) {
   VarDump::dd($var, $msg);
}